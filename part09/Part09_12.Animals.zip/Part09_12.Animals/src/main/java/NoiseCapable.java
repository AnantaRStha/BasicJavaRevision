public interface NoiseCapable {
    public void makeNoise();
}
